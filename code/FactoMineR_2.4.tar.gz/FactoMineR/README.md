# FactoMineR

You can see the Website dedicated to FactoMineR (<a href="http://factominer.free.fr/index.html">link for English version</a>, and for <a href="http://factominer.free.fr/index_fr.html">the French version</a>)


How do you install the latest version of FactoMineR available on GitHub?

```{r}
if (!require("devtools")) install.packages("devtools")
library(devtools)
install_github("husson/FactoMineR")
```