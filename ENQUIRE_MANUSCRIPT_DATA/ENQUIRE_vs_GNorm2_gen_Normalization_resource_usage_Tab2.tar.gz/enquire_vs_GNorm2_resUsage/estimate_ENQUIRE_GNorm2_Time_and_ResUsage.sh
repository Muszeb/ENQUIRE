#!/bin/bash

THREADS=1 # change to model effect of parallelization 
CSIZEX=1 # change to model effect of corpus size 

#rm "$(pwd)/input"/*
#rm "$(pwd)/output"/*
echo "generate input"
for i in $(seq "$CSIZEX");do
  if [[ $i -lt 2 ]];then
    cat "$(pwd)/examples/PubMed.input.pubtator" > "$(pwd)/input/PubMed.input.pubtator"
  else 
    cat "$(pwd)/examples/PubMed.input.pubtator" > tmp.txt
    while IFS= read -r line; do
      # Extract the line number
      line_number=$(echo "$line" | cut -d '|' -f 1)

      # Replace the leading digits with a unique identifier 
      new_line="$((line_number * $i))"

      # Perform the replacement using sed
      sed -i "s/^$line_number|/$new_line|/" "tmp.txt"

    done < tmp.txt
    cat tmp.txt >> "$(pwd)/input/PubMed.input.pubtator"
  fi
done

rm -f -- tmp.txt

echo "$(grep -e "^$" -c < input/PubMed.input.pubtator) files"


export INPUT=input
export OUTPUT=output
export THREADS
export CSIZEX

# WATCHED_PID=$({ python ~/tam_textmining/code/ENQUIRE_gNER_gNORM_pipeline.py --file "$(pwd)/input/PubMed.input.pubtator" --ncores $THREADS --datadir ~/tam_textmining/ \
#  --outtag "enquire_gNorm_time_${THREADS}threads_${CSIZEX}copy.tsv" \
# > "enquire_gNorm_time_${THREADS}threads_${CSIZEX}copy.txt" 2> err.log & } && echo $!)

# see https://github.com/ncbi/GNorm2
WATCHED_PID=$({ ./GNorm2.sh input output \
> "gnorm2example_${THREADS}thread_${CSIZEX}copy.stdout" 2> "gnorm2example_${THREADS}thread_${CSIZEX}copy.stderr" & } && echo $!)

# Header for the TSV output
echo -e "PGID\tPPID\tProcess ID\tThread ID\tWall time\tTime since start (s)\tTime of process (s)\tResidual set size (RSS)\tCPU Percentage" > "gnorm2resusage_${THREADS}thread_${CSIZEX}copy.tsv"

while true; do
  # Check if the watched process is still running
  if ! kill -0 "${WATCHED_PID}" 2>/dev/null; then
    echo "Process with PID ${WATCHED_PID} has terminated. Exiting."
    break
  fi

  # Iterate through each process using ps for the WATCHED_PID
  ps -eHo pgid,ppid,pid,tid,etime,time,rss,%cpu --cumulative S | awk -v pid="${WATCHED_PID}" '$1 == pid || $2 == pid || $3 == pid' | \
  while read -r pgid ppid pid tid etime time rss cpu; do
    # Convert elapsed time (etime) to seconds
    seconds=$(echo "${etime}" | awk -F: '{print ($1 * 3600) + ($2 * 60) + $3}')

    # Convert process time to seconds
    process_time=$(echo "${time}" | awk -F: '{print ($1 * 3600) + ($2 * 60) + $3}')

    # Get the current time in seconds
    current_time=$(date +%s)

    # Calculate CPU percentage
    cpu_percentage=${cpu}

    # Output the information in TSV format
    echo -e "${pgid}\t${ppid}\t${pid}\t${tid}\t${current_time}\t${seconds}\t${process_time}\t${rss}\t${cpu_percentage}" >> "gnorm2resusage_${THREADS}thread_${CSIZEX}copy.tsv"

  done

  # Sleep for 1 second before the next iteration
  sleep 1
done