import os
import sys
#from nltk.corpus.reader.plaintext import PlaintextCorpusReader
import numpy as np 
import pandas as pd
import itertools
import multiprocessing as mp
from collections import OrderedDict
from nltk.stem import WordNetLemmatizer
import re
import random
from Bio import Entrez
from Bio.Entrez import efetch,esearch, read
from scipy.spatial import distance_matrix
import networkx as nx
import bz2
import json
import gzip
from multiprocess import Pool
import time
from itertools import islice
import nltk
nltk.download('wordnet')
nltk.download('stopwords')
from nltk.corpus import stopwords
import string
nltk.download('words')
from nltk.corpus import words
from nltk.stem import WordNetLemmatizer
from english_words import english_words_set
from thinc.api import fix_random_seed
import spacy
import scispacy
import xmltodict
import dpath
from collections import ChainMap
import random
from Bio import pairwise2
from itertools import starmap
import csv
import warnings
import threading
import argparse
try:
    import _pickle as pickle
except ModuleNotFoundError:
    	import pickle

# Pickle a file and then compress it into a file with extension 
def compress_pickle(title, data):
	with bz2.BZ2File(title + ".pbz2", "w") as f: 
		pickle.dump(data, f)

# decompress .pbz2 file to a variable
def decompress_pickle(file):
	data = bz2.BZ2File(file, "rb") 
	data = pickle.load(data)
	return data

#### LOAD FULTXT DICT from .pbz file ####
parser = argparse.ArgumentParser()
parser.add_argument("--file",metavar='dictfile',type=str,required=True,
    help="Path to Pubtator text file containing article abstracts to be processed.")
parser.add_argument('--ncores',default=1,type=int,
	help="Number of threads for parallel processing")
parser.add_argument('--datadir',metavar='sd',required=True,
	help="path to main ENQUIRE directory, where 'code/' and 'input' subfolders reside")
## optional cell/abbreviations tags ##
parser.add_argument('--nocelltags', default=False, action='store_true',
	help="disable removing of character spans tagged as cell lines or types (e.g. 'CD8+ T-cell')?")
parser.add_argument('--noabbstags', default=False, action='store_true',
	help="disable removing of ambiguous definition/abbreviation spans tagged as cell lines or types (e.g. 'collagen-related peptide (CRP)')?")
###
parser.add_argument('--outtag',default="ENQUIRE_NLM_gNORM.tsv", help="Path/to/output_file.tsv (TSV file with PMIDs and Normalized genes columns) - default: 'ENQUIRE_NLM_gNORM.tsv'")
#
args = parser.parse_args()
#
dictfile=args.file

###
ncores=args.ncores
sd=args.datadir
tag="ENQUIRE_gNER_gNORM"
wd=os.getcwd()
#### START TIME ####
print("start time elapse...")
all_time=time.time()
# ful_dict=decompress_pickle(dictfile)
# # keys must be integere-translatable #
# ful_dict=dict({int(re.findall("[0-9]+",k)[0]):v for k,v in ful_dict.items()})
### process pubtator file ###
with open(args.file,'r') as file:
	pubtatorinput=file.read().split('\n\n')

pubtatorinput=[x for x in pubtatorinput if x != '']
ful_dict={i:re.sub("\n?[0-9]+\|[at]\|"," ",x) for i,x in zip(range(len(pubtatorinput)),pubtatorinput)}
##### FIND CELL ENTITIES AND ABBREVIATIONS #####
exec(open(sd+"/code/schwartz_hearst.py").read())
#
#abs_dict=dict({k:v for k,v in abs_dict.items() if k in pmids})
# cure abstracts
greek_alphabet = {
	b'\xce\x91':	 'Alpha',
	b'\xce\x92':	 'Beta',
	b'\xce\x93':	 'Gamma',
	b'\xce\x94':	 'Delta',
	b'\xce\x95':	 'Epsilon',
	b'\xce\x96':	 'Zeta',
	b'\xce\x97':	 'Eta',
	b'\xce\x98':	 'Theta',
	b'\xce\x99':	 'Iota',
	b'\xce\x9a':	 'Kappa',
	b'\xce\x9b':	 'Lamda',
	b'\xce\x9c':	 'Mu',
	b'\xce\x9d':	 'Nu',
	b'\xce\x9e':	 'Xi',
	b'\xce\x9f':	 'Omicron',
	b'\xce\xa0':	 'Pi',
	b'\xce\xa1':	 'Rho',
	b'\xce\xa3':	 'Sigma',
	b'\xce\xa4':	 'Tau',
	b'\xce\xa5':	 'Upsilon',
	b'\xce\xa6':	 'Phi',
	b'\xce\xa7':	 'Chi',
	b'\xce\xa8':	 'Psi',
	b'\xce\xa9':	 'Omega',
	b'\xce\xb1':	 'alpha',
	b'\xce\xb2':	 'beta',
	b'\xce\xb3':	 'gamma',
	b'\xce\xb4':	 'delta',
	b'\xce\xb5':	 'epsilon',
	b'\xce\xb6':	 'zeta',
	b'\xce\xb7':	 'eta',
	b'\xce\xb8':	 'theta',
	b'\xce\xb9':	 'iota',
	b'\xce\xba':	 'kappa',
	b'\xce\xbb':	 'lamda',
	b'\xce\xbc':	 'mu',
	b'\xce\xbd':	 'nu',
	b'\xce\xbe':	 'xi',
	b'\xce\xbf':	 'omicron',
	b'\xcf\x80':	 'pi',
	b'\xcf\x81':	 'rho',
	b'\xcf\x83':	 'sigma',
	b'\xcf\x84':	 'tau',
	b'\xcf\x85':	 'upsilon',
	b'\xcf\x86':	 'phi',
	b'\xcf\x87':	 'chi',
	b'\xcf\x88':	 'psi',
	b'\xcf\x89':	 'omega'}
#
def greek_sub_a(m):
	if m.group() is not None:
		try: 
			return greek_alphabet[m.group().encode('utf-8')]
		except:
			return ''
#
def greek_sub_f(m):
	if m.group() is not None:
		try: 
			return greek_alphabet[m.group().encode('utf-8')]
		except:
			return ' '
#
# replace greek, non-ASCII spellings
ful_dict=dict({k:re.sub('[\u0080-\uFFFF]',greek_sub_f,v) for k,v in ful_dict.items()})
#
def abb_pairs(s):
	random.seed(2202)
	os.environ['PYTHONHASHSEED'] = str(2202)
	np.random.seed(2202)
	d=extract_abbreviation_definition_pairs(doc_text=s,first_definition=True)
	d={str(k):str(v) for k,v in d.items()}
	# Deal with abbreviations of plurals etc...
	pattern = re.compile("^[a-z][A-Z]+$|^[A-Z]+[a-z]$")
	items=list(d.items())
	for k,v in items:
		if pattern.match(k):
			#print("found plural/unlemmatized abbreviation:",k)
			sing=re.sub("^[a-z]|[a-z]$","",k)
			#print("lemmatization:",sing)
			d[sing]=v
	return d #{str(k):str(v) for k,v in d.items()}
#
def celliNER(items,model):
	random.seed(2202)
	spacy.util.fix_random_seed(2202)
	fix_random_seed(2202)
	np.random.seed(2202)
	os.environ['PYTHONHASHSEED'] = str(2202)
	nlp = globals()[model]
	items = [(x[1],x[0]) for x in items]
	docs = nlp.pipe(items, as_tuples=True)
	d={int(tpl[1]):list(set([str(ent) for ent in tpl[0].ents if ent.label_ in ["CELL_TYPE", "CELL_LINE"]])) for tpl in docs}
	### SAVE SPANS ###
	# docs = nlp.pipe(items, as_tuples=True)
	# dspans={int(tpl[1]):list(set([(str(ent),ent.start_char,ent.end_char) for ent in tpl[0].ents if ent.label_ in ["CELL_TYPE", "CELL_LINE"]])) for tpl in docs}
	# dfspans=pd.DataFrame(itertools.chain.from_iterable([[(k,)+span for span in v] for k,v in dspans.items()]),columns=['PMID','Entity','Start','End'])
	# #### write to file!
	# global_lock = threading.Lock()	
	# with global_lock:	
	# 	dfspans.to_csv(os.getcwd()+"/ENQUIRE_cellNER_NLM.tsv",index=False,header=False,sep='\t',mode='a')
	# #	
	# print("spans saved")
	# ###	
	return d
#
def distro(data,ncores,d1):
	chunks=[x.tolist() for x in np.array_split(data,ncores)]
	d1s=[d1+str(i) for i in range(0,ncores)]
	return iter([(chunks[i],d1s[i]) for i in range(0,ncores)])
#
# find cell line names 

# TEST NORMALIZATION WITH/WITHOUT CELL/ABB TAGS

if args.nocelltags:
	cell_dict={k:[""] for k in ful_dict.keys()}

else:
	print("finding cell lines/types")
	print("loading scispacy model")
	nlp = spacy.load("en_ner_jnlpba_md")

	if len(list(ful_dict.items())) < ncores:
		ncores = len(list(ful_dict.items()))

	var_names_nlp=["nlp_"+str(i) for i in range(ncores)]
	for name in var_names_nlp:
		random.seed(2202)
		spacy.util.fix_random_seed(2202)
		fix_random_seed(2202)
		np.random.seed(2202)
		os.environ['PYTHONHASHSEED'] = str(2202)
		globals()[name] = nlp

	with Pool(ncores) as pool:
		print("scispacy starmap ...")
		random.seed(2202)
		spacy.util.fix_random_seed(2202)
		fix_random_seed(2202)
		np.random.seed(2202)
		os.environ['PYTHONHASHSEED'] = str(2202)
		res=pool.starmap(celliNER,distro(list(ful_dict.items()),ncores,'nlp_'))

	cell_dict={}
	for d in res:
		cell_dict.update(d)

if args.noabbstags:
	abb_dict={k:dict() for k in ful_dict.keys()}
else:
	print("finding abbreviations")
	abb_dict=dict({key:abb_pairs(val) for key,val in ful_dict.items()})
	abb_dict={pmid:{ab:df for ab,df in abb_dict[pmid].items() if df not in cell_dict[pmid]} for pmid in list(abb_dict.keys())} 

#abb_dict=pd.Series(abb_dict)
#print(ful_dict)
#print(abb_dict)
#keys_pub={k:list(set(v)) for k,v in keys_pub.items()}

# TEST NORMALIZATION WITHOUT CELL/ABB TAGS

#abb_dict={k:dict() for k in abb_dict.keys()}
#cell_dict={k:[""] for k in cell_dict.keys()}

###### TOKENIZATION ######

if all([len(d)==0 for d in [abb_dict,ful_dict,cell_dict]]):
	print("### WARNING: all necessary dictionary have length 0 - did you set etype=Mesh? ###")
	compress_pickle(wd+'/'+tag+'_ids_to_abs', dict({}))
else:
	print("remove cell or abbreviation definitions from text")
	#
	def absurge(i,ful=ful_dict,abb=abb_dict,cell=cell_dict):
		#0.
		if abb[i] or cell[i]:
			# LIST ORDER MAY DIFFER BETWEEN RUNS! DIFFERENT RESULTS COULD BE OBTAINED WHEN REMOVING STRINGS #
			# use alphabetical, THEN decreasing length (reverse) as a proxy for more specific -> less specific order
			for v in sorted(sorted(list(abb[i].values()) + cell[i]),key=len,reverse=True):
				ful[i]=re.sub(re.escape(v), "", ful[i])
	#
	for i in ful_dict.keys():
		absurge(i)
	#
	### TOKENIZATION ### 
	# cure abstracts
	greek_alphabet = {
		b'\xce\x91':	 'Alpha',
		b'\xce\x92':	 'Beta',
		b'\xce\x93':	 'Gamma',
		b'\xce\x94':	 'Delta',
		b'\xce\x95':	 'Epsilon',
		b'\xce\x96':	 'Zeta',
		b'\xce\x97':	 'Eta',
		b'\xce\x98':	 'Theta',
		b'\xce\x99':	 'Iota',
		b'\xce\x9a':	 'Kappa',
		b'\xce\x9b':	 'Lamda',
		b'\xce\x9c':	 'Mu',
		b'\xce\x9d':	 'Nu',
		b'\xce\x9e':	 'Xi',
		b'\xce\x9f':	 'Omicron',
		b'\xce\xa0':	 'Pi',
		b'\xce\xa1':	 'Rho',
		b'\xce\xa3':	 'Sigma',
		b'\xce\xa4':	 'Tau',
		b'\xce\xa5':	 'Upsilon',
		b'\xce\xa6':	 'Phi',
		b'\xce\xa7':	 'Chi',
		b'\xce\xa8':	 'Psi',
		b'\xce\xa9':	 'Omega',
		b'\xce\xb1':	 'alpha',
		b'\xce\xb2':	 'beta',
		b'\xce\xb3':	 'gamma',
		b'\xce\xb4':	 'delta',
		b'\xce\xb5':	 'epsilon',
		b'\xce\xb6':	 'zeta',
		b'\xce\xb7':	 'eta',
		b'\xce\xb8':	 'theta',
		b'\xce\xb9':	 'iota',
		b'\xce\xba':	 'kappa',
		b'\xce\xbb':	 'lamda',
		b'\xce\xbc':	 'mu',
		b'\xce\xbd':	 'nu',
		b'\xce\xbe':	 'xi',
		b'\xce\xbf':	 'omicron',
		b'\xcf\x80':	 'pi',
		b'\xcf\x81':	 'rho',
		b'\xcf\x83':	 'sigma',
		b'\xcf\x84':	 'tau',
		b'\xcf\x85':	 'upsilon',
		b'\xcf\x86':	 'phi',
		b'\xcf\x87':	 'chi',
		b'\xcf\x88':	 'psi',
		b'\xcf\x89':	 'omega',}
	#
	english_words_set= english_words_set.union(set(words.words()))
	english_words_set=english_words_set - set(greek_alphabet.values())	
	#
	#############
	print("tokenize...")
	# process and save IDs to Abs dictionaries
	def cleansing_1x(i,ful,english_words_set,greek_alphabet):
		#
		ful=globals()[ful]
		english_words_set=globals()[english_words_set]
		greek_alphabet=globals()[greek_alphabet]
		# Works on one abs at a time
		x=ful[i]
		#
		x=x.replace('\n',' ')
		x=re.sub('\/',' ',x)
		x=re.sub(',',' ',x)
		x=x.replace('.',' ')
		x=re.sub('[^\\w-]+',' ',x)
		x=re.sub(r' \d+ ',' ', x)
		# multiple spaces become single spaces
		x=re.sub(r'\s+', ' ', x)
		# find all non-ascii, manipulate in separate list and concatenate
		def find_greek(ab,greek_alphabet=greek_alphabet):
			def greek_sub(m):
				if m.group() is not None:
					try: 
						return greek_alphabet[m.group().encode('utf-8')]
					except:
						return ' '
			def undash(w):
				notdash=''.join(w.split('-'))
				return w+' '+notdash
			mat=re.findall('[a-zA-Z\d\-]*[\u0080-\uFFFF][a-zA-Z\d]*|[\u0080-\uFFFF]+\-[a-zA-Z\d]+',ab)
			if len(mat)==0:
				return ab
			else:
				# version without any greek letter -> WRONG, produces artifacts! (IL-1beta->IL-1)
				
				#matout=[re.sub('[\u0080-\uFFFF]','',i) for i in mat]
				#matout=' '.join(matout)
				#
				mat=list(set(mat))
				# translation of greek characters to strings
				mat=[re.sub('[\u0080-\uFFFF]',greek_sub,i) for i in mat]
				#
				mat=[undash(w) for w in mat]
				mat=' '.join(mat)
				return ab+' '+mat+' '#+matout
		#
		x=find_greek(x)
		# refinements
		x=re.sub(' [\u0080-\uFFFF-\d]* ', ' ', x)
		x=re.sub('\*', ' ', x)
		# multiple spaces become single spaces
		x=re.sub(r'\s+', ' ', x)
		# LEMMATIZATION
		stemmer = WordNetLemmatizer()
		def lemma(document,mod):
			if mod=='a':
				document=document.split()
				document=[stemmer.lemmatize(w, pos='a') for w in document]
				document=' '.join(document)
			if mod=='v':
				document=document.split()
				document=[stemmer.lemmatize(w, pos='v') for w in document]
				document=' '.join(document)
			else:
				document=document.split()
				document=[stemmer.lemmatize(w) for w in document]
				document=' '.join(document)
			return document	
		#
		x=lemma(x,'n')
		x=lemma(x,'v')
		x=lemma(x,'a')
		#	
		# REMOVE ALL ENGLISH WORDS 
		x=x.split()
		#
		def clean_dash(w,P,english_words_set=english_words_set):			
			# pattern "-word" or "word-"
			ds=list(window(w.split('-')))
			if len(ds)==0:
				return w
			else:
				# no "word-word-word" is possible
				for pair in ds:
					pair=[stemmer.lemmatize(p, pos='a') for p in pair]
					pair=[stemmer.lemmatize(p, pos='v') for p in pair]
					pair=[stemmer.lemmatize(p, pos='n') for p in pair]
					if not all(p.lower() in english_words_set for p in pair):
						# then remove the english word
						g='-'.join(pair)
						P.append(g)	
		#
		def dedash(w,P,english_words_set=english_words_set):
			def window(seq, n=2):
				# "Returns a sliding window (of width n) over data from the iterable"
				# s -> (s0,s1,...s[n-1]), (s1,s2,...,sn), ...                   "
				it = iter(seq)
				result = tuple(islice(it, n))
				if len(result) == n:
					yield result    
				for elem in it:
					result = result[1:] + (elem,)
					yield result
			# pattern "-word" or "word-"
			def lemma(pair):
				pair=[stemmer.lemmatize(p, pos='a') for p in pair]
				pair=[stemmer.lemmatize(p, pos='v') for p in pair]
				pair=[stemmer.lemmatize(p, pos='n') for p in pair]
				return(pair)
			#
			ws=w.split('-')
			if len(ws)==1:
				return w
			else:
				ws=lemma(ws)
				if ws[-1] in english_words_set: # "gene-related", "gene-dependent". no .lower(), because always comes after at least 1 word!
						del ws[-1]
				if ws[0].lower() in english_words_set and len(ws[0])>2: # "pre-caspase", "anti-PDCD1"
						del ws[0]
				if len(w.split('-'))>2:
					ds=list(window(w.split('-')))
					ds=[t for t in ds if not all([j in english_words_set for j in t])]
					ds=['-'.join(list(t)) for t in ds]
					P+=ds
				return '-'.join(ws)
		P=[]
		x=[dedash(w,P) for w in x]	
		x+=P
		x=[w for w in x if w.lower() not in english_words_set]
		x=[w for w in x if w]
		x=[w for w in x if w != '']		
		x=[re.sub("^-|-$",'',w) for w in x]
		# prepare stopwords
		all_stopwords = stopwords.words('english')
		all_stopwords+=[i.upper() for i in all_stopwords]
		all_stopwords+=[i.capitalize() for i in all_stopwords]
		all_stopwords+=list(string.ascii_lowercase)
		all_stopwords+=list(string.ascii_uppercase)
		# stop "*co*-occurrence"
		all_stopwords+=['co','Co','CO','M1','M2']
		#
		x=list(set(x))
		# more careful evaluation with lowercase (not necessary if you use reference aliases)
		# x = [i.lower() for i in x]
		return i,x #'!'.join(x)
	#
	def greek_sub_a(m):
		if m.group() is not None:
			try: 
				return greek_alphabet[m.group().encode('utf-8')]
			except:
				return ''
	#
	print("duplicate dictionaries for parallelization...")

	#ncores= int(sys.argv[3]) #32

	var_names_abs=["ful_dict_"+str(i) for i in range(ncores)]
	var_names_syn=["english_words_set_"+str(i) for i in range(ncores)]
	var_names_abb=["greek_alphabet_"+str(i) for i in range(ncores)]

	for name in var_names_abs:
		globals()[name] = ful_dict	


	for name in var_names_syn:
		globals()[name] = english_words_set #aliasd=pd.Series(aliasdf['aliases'].tolist(),index=aliasdf.symbol).to_dict()


	for name in var_names_abb:
		globals()[name] = greek_alphabet
	#
	def distro(datal,ncores,d1,d2,d3):
		# d1 and d2 are strings
		# set repetitions
		rep=int(len(datal)/ncores)+2
		d1s=[d1+str(i) for i in range(0,ncores)]*rep
		d2s=[d2+str(i) for i in range(0,ncores)]*rep
		d3s=[d3+str(i) for i in range(0,ncores)]*rep
		#print(d1s)
		#d2s=[d2+str(i) for i range(0,ncores)]*rep
		return iter((datal[i],d1s[i],d2s[i],d3s[i]) for i in range(0,len(datal)))
	#
	with Pool(ncores) as pool:
		#res=[pool.apply(find_in_series,args=(idd,globals()["abs_dict_"+str(ids.index(idd))],globals()["syn_dict_"+str(ids.index(idd))])) for idd in ids]   
		print("starmap...")
		abs_dict=dict(pool.starmap(cleansing_1x,distro(list(ful_dict.keys()),ncores,'ful_dict_','english_words_set_','greek_alphabet_')))
		print("store in dictionary")
		#res=dict(res)
	#
	abs_dict=dict({k:[re.sub('[\u0080-\uFFFF]',greek_sub_a,i) for i in v] for k,v in abs_dict.items()})

##### GENE NER AND NORMALIZATION #####
pmid_to_abs=abs_dict

if len(pmid_to_abs)==0:
	print("PMID to abstract dictionary is empty - skip NER")
	compress_pickle(wd+"/"+tag+"_ids_to_genes",dict({}))
###
else:
	english_words_set= english_words_set.union(set(words.words()))
	#
	greek_alphabet = {
		b'\xce\x91':	 'Alpha',
		b'\xce\x92':	 'Beta',
		b'\xce\x93':	 'Gamma',
		b'\xce\x94':	 'Delta',
		b'\xce\x95':	 'Epsilon',
		b'\xce\x96':	 'Zeta',
		b'\xce\x97':	 'Eta',
		b'\xce\x98':	 'Theta',
		b'\xce\x99':	 'Iota',
		b'\xce\x9a':	 'Kappa',
		b'\xce\x9b':	 'Lamda',
		b'\xce\x9c':	 'Mu',
		b'\xce\x9d':	 'Nu',
		b'\xce\x9e':	 'Xi',
		b'\xce\x9f':	 'Omicron',
		b'\xce\xa0':	 'Pi',
		b'\xce\xa1':	 'Rho',
		b'\xce\xa3':	 'Sigma',
		b'\xce\xa4':	 'Tau',
		b'\xce\xa5':	 'Upsilon',
		b'\xce\xa6':	 'Phi',
		b'\xce\xa7':	 'Chi',
		b'\xce\xa8':	 'Psi',
		b'\xce\xa9':	 'Omega',
		b'\xce\xb1':	 'alpha',
		b'\xce\xb2':	 'beta',
		b'\xce\xb3':	 'gamma',
		b'\xce\xb4':	 'delta',
		b'\xce\xb5':	 'epsilon',
		b'\xce\xb6':	 'zeta',
		b'\xce\xb7':	 'eta',
		b'\xce\xb8':	 'theta',
		b'\xce\xb9':	 'iota',
		b'\xce\xba':	 'kappa',
		b'\xce\xbb':	 'lamda',
		b'\xce\xbc':	 'mu',
		b'\xce\xbd':	 'nu',
		b'\xce\xbe':	 'xi',
		b'\xce\xbf':	 'omicron',
		b'\xcf\x80':	 'pi',
		b'\xcf\x81':	 'rho',
		b'\xcf\x83':	 'sigma',
		b'\xcf\x84':	 'tau',
		b'\xcf\x85':	 'upsilon',
		b'\xcf\x86':	 'phi',
		b'\xcf\x87':	 'chi',
		b'\xcf\x88':	 'psi',
		b'\xcf\x89':	 'omega',
	}
	#
	# special handling of greek letters: remove them from english dictionary
	english_words_set=english_words_set - set(greek_alphabet.values())	
	# SETUP GENE DICTIONARIERS FOR H.s and M.m
	# human and mouse genes
	#aliasdf = pd.read_csv(sd+'input/gene_aliases_df.tsv',sep='\t')
	aliasdf = pd.read_csv(sd+'/input/aliases_uniprotensembl_as_df_Paralogues.tsv',sep='\t')
	aliasdf=aliasdf.dropna()
	#
	def alclean(al):
		def greek_sub_a(m):
			if m.group() is not None:
				try: 
					return greek_alphabet[m.group().encode('utf-8')]
				except:
					return ''
			#
		if al in english_words_set:
			return False
		elif bool(re.search("^[a-zA-Z]{1,2}$|^[\W\d]+$", al)):
			return False
		elif al in greek_alphabet.values():
			return False
		else:
			al=re.sub("[\(\)\[\]]",'',al)
			al=re.sub('[\u0080-\uFFFF]',greek_sub_a,al)
			return al
	#
	aliasdf['alias_symbol']=aliasdf['alias_symbol'].apply(alclean,1)
	# ``ser.astype(object).apply()``
	# remove 1-2 letters only aliases
	aliasdf=aliasdf[~(aliasdf.alias_symbol==False)]
	# aliases=aliasdf.aliases.tolist()
	# # unless they are reference genes => regardless being a reference gene
	# #refs=aliasdf.symbol.tolist()
	# al=al.split(';')
	# al=[a for a in al if a not in english_words_set]
	# al=[a for a in al if not bool(re.search("^[a-zA-Z]{1,2}$|^[\W\d]+$", a))]
	# al=[re.sub("[\(\)\[\]]",'',a) for a in al]
	# al=[a for a in al if a not in greek_alphabet.values()]	
	# return ';'.join(al)
	# # #
	# aliasdf['aliases']=aliasdf.aliases.apply(alclean,1)
	# #
	# # convert to an alias-symbol series
	# def serialal(aliasdf):
	# 	def reser(row):
	# 		als=row[1].split(';')
	# 		sym=row[0]
	# 		return list(itertools.product(als,[sym]))	
	# 	#
	# 	xl=aliasdf.apply(reser,1)
	# 	nl=list(itertools.chain(*xl.tolist()))
	# 	nl=pd.DataFrame(nl)
	# 	nl.index=nl[0]
	# 	AliasS=pd.Series(nl[1])
	# 	return AliasS
	# #
	#aliass=serialal(aliasdf)	
	aliass=pd.Series(aliasdf.symbol.tolist(),index=aliasdf.alias_symbol.tolist())
	#aliass=aliass[~aliass.index.duplicated(keep='first')]
	#
	#dictionarize
	#
	#bad_hits=list(set(filter(lambda x: re.match("^[a-zA-Z]{1,2}$",str(x)),aliases)))
	#aliasdf=aliasdf[~aliasdf['aliases'].isin(bad_hits)]
	#
	syms=aliasdf.symbol.tolist()
	###
	# with gzip.open(wd+'ids_to_abs_raw.json.gz', 'rt', encoding='UTF-8') as zipfile:
	#     pmids_to_raw_abs = json.load(zipfile)
	# #
	# # ACHTUNG! KEYS ARE NOW STRINGS
	# pmids_to_raw_abs={int(k):v for k,v in pmids_to_raw_abs.items()} 
	# # sub greek letters

	###
	print("PMIDs and alias DF loaded")
	#
	print("set multithreading")
	##
	print("duplicate PMIDs-abstracts and aliasases dictionary for parallelization...")

	#ncores= int(sys.argv[3]) #32

	var_names_abs=["abs_dict_"+str(i) for i in range(ncores)]
	var_names_syn=["syn_dict_"+str(i) for i in range(ncores)]
	var_names_abb=["abb_dict_"+str(i) for i in range(ncores)]
	var_names_ful=["ful_dict_"+str(i) for i in range(ncores)]

	for name in var_names_abs:
		globals()[name] = pmid_to_abs	


	for name in var_names_syn:
		globals()[name] = aliass #aliasd=pd.Series(aliasdf['aliases'].tolist(),index=aliasdf.symbol).to_dict()


	for name in var_names_abb:
		globals()[name] = abb_dict

	for name in var_names_ful:
		globals()[name] = ful_dict

	#
	# to avoid overtaking the max number of threads, split the list (feed as first "climbME" argument)
	genes_pub=dict({sym:[] for sym in syms})
	#chunks = iter([list(pmid_to_abs.keys())[x:x+ncores] for x in range(0, len(list(pmid_to_abs.keys())), ncores)])
	#
	# bingo=['OAS1',
	# 	'Skull21',
	# 	'Skull14',
	# 	'Skull22',
	# 	'IGKV1-16',
	# 	'Sdtq10',
	# 	'Rpl18',
	# 	'Rpl14',
	# 	'Rpl13',
	# 	'CYRIB',
	# 	'Skull20',
	# 	'Skull16',
	# 	'Lgals1',
	# 	'Sdtq11',
	# 	'L1cam',
	# 	'Pdilt',
	# 	'PDCD1']
	#	


	# def find_in_tokens(idd,abs_dict,syn_dict):
	# 	#
	# 	tok=abs_dict[idd]
	# 	#
	# 	def mappal(alit):
	# 	#print(alit)
	# 		k,v = alit
	# 		#bool(re.search("[\W\s]+al+[\W\s]",txt))
	# 		#print(v)
	# 		if any(al in tok for al in v.split(';')):
	# 			#print("found",k)
	# 			return k
	# 	#
	# 	hit=list(map(mappal,syn_dict.items())) 
	# 	# df[df.columns.intersection(l)]
	# 	hit=[i for i in hit if i]
	# 	# hit contains gene entities. What about "GENE1-GENE2" entities (if any)?
	# 	# delete any word that matches an alias per se (if so, should be in hit already)
	# 	allal=';'.join(syn_dict.values()).split(';')
	# 	#
	# 	g1g2= list(set(tok) - set(allal))
	# 	g1g2=[w for w in g1g2 if '-' in w]		
	# 	#
	# 	if len(g1g2) > 0:
	# 		#	
	# 		#print("A gene-gene occurrence(?)",g1g2)
	# 		for pair in g1g2:
	# 			pair=pair.split('-')
	# 			# BOTH must be gene aliases ("GENE-dirt" occurrences will be discarded)
	# 			if all(p in allal for p in pair):
	# 				#
	# 				for p in pair:
	# 				#print("found", pair[0],'-',pair[1],'pair...')
	# 				# assuming an alias is unique to its reference gene:
	# 					hit+=[k for k in syn_dict if p in syn_dict[k].split(';')] 
	# 	hit=list(set(hit))
	# 	hit=[(h,idd) for h in hit]
	# 	return hit 
					
	# one chunk multithreaded at a time

	#
	def find_in_series(idd,abs_dict,syn_dict,abb_dict,ful_dict):
		#
		global_lock = threading.Lock()	
		#
		#print(idd)
		#print(idd,abs_dict,syn_dict,abb_dict)
		abs_dict=globals()[abs_dict]
		syn_dict=globals()[syn_dict]
		abb_dict=globals()[abb_dict]
		ful_dict=globals()[ful_dict]
		#
		tok=abs_dict[idd]
		abb=abb_dict[idd]
		ful=ful_dict[idd]
		#print(tok,abb)
		#
		hits=syn_dict[syn_dict.index.intersection(tok)]
		if len(hits)>0:
			#
			if len(abb.keys()) > 0:
				sus=set(set(hits.index) & abb.keys())
				#
				if len(sus) > 0:
					#
					def pw2(abb,al):
						s=pairwise2.align.globalms(abb, al,1, -1, -1, -0.5,score_only=True)
						s=s/len(abb)
						return s
					#
					# inspect abbreviation
					for a in sus:
						seq=abb[a]
						if type(syn_dict[a]) == str: # no paralogues
							sym=str(syn_dict[a])
							als=list(syn_dict[syn_dict == sym].index)
						else: # paralogues
							sym=syn_dict[a].tolist()
							als=set(itertools.chain.from_iterable([list(syn_dict[syn_dict == s].index) for s in sym]))
						#print(list(itertools.product([seq],als)))
						#try:
						if (m := max(starmap(pw2,itertools.product([seq],als)))) < 0.15:
							hits.drop(labels = [a],inplace=True)
							print("suspicious token/abbreviation:",a,abb[a],m)
							# SAVE EXCLUDED TOKENS #
							# dfabbs=pd.DataFrame([[idd,a,abb[a],m]])	
							# with global_lock:	
							# 	dfabbs.to_csv(os.getcwd()+"/ENQUIRE_negAbbsNER_NLM.tsv",index=False,header=False,sep='\t',mode='a')
	
						#else: 
							# remove sub-tokens of the abbreviation??? (may increase false negatives, but think of "IL2 RECEPTOR") 
						#
						#
						# except:
						# 	print("MAX ERRROR?")
						# 	print(idd)
						# 	print(a)
						# 	#
						# 	try:
						# 		print(list(starmap(pw2,itertools.product([seq],als))))
						# 	except:
						# 		print('LIST ERROR?')
						# 		print([seq])
						# 		print(als)
						# 		#print(pw2(*([seq],als])))
						# 	#
		#
		### check gene1/gene2 and gene1-gene2 instances ###
		g1g2=list(set(tok) - set(hits.index))
		g1g2=[w for w in g1g2 if re.match('[\w]+[\-\/][\w]+',w)]
		#
		unihits=set(hits.to_list())
		#
		if len(g1g2) > 0:
			#				
			#print("A gene-gene occurrence(?)",g1g2)
			for pair in g1g2:
				pair=re.findall('[\w]+-[0-9]+|[\w]+',pair)#re.split('([\-\/])',pair)
				# BOTH must be gene aliases ("GENE-dirt" occurrences will be discarded)
				if all(p in syn_dict.index for p in pair):
					#
					matchp=syn_dict[pair]
					hits=pd.concat([hits,matchp])#hits.combine_first(matchp)
					unihits.union(set(matchp.to_list()))
					#
		#
		#
		### now we need to find gene boundaries in full txt to compare with gnormplus ### 
		# def find_all_spans(ner,ful):
		# 	pattern = re.compile(re.escape(ner))			
		# 	# Using re.finditer to get all matching character spans
		# 	matches = pattern.finditer(ful)
		# 	return [(ner,match.start(),match.end()) for match in matches]
		# # # Extracting and printing the matched spans
		# # for match in matches:
		# #     print("Start:", match.start(), "End:", match.end(), "Match:", match.group())
		# # nered=hits.index.to_list()
		# spans=[find_all_spans(ner,ful) for ner in hits.index.to_list()]
		# spans=pd.DataFrame(list(itertools.chain.from_iterable(spans)),columns=['GeneAlias','Start','End'])
		# aliasdict=syn_dict.to_dict()
		# spans['GeneSymbol']=[aliasdict[k] for k in spans.GeneAlias]
		# #### write to file!
		# spans.to_csv(os.getcwd()+"/ENQUIRE_NER_"+str(idd)+".tsv",index=False,sep='\t')
		# print("spans saved")
		#
		####
		hit=[(h,idd) for h in unihits]
		return hit 
		#

	#
	print("input %s corpus" % (tag))
	#
	#while (ids := next(chunks,False)):     
	def distro(datal,ncores,d1,d2,d3,d4):
		# d1 and d2 are strings
		# set repetitions
		rep=int(len(datal)/ncores)+2
		d1s=[d1+str(i) for i in range(0,ncores)]*rep
		d2s=[d2+str(i) for i in range(0,ncores)]*rep
		d3s=[d3+str(i) for i in range(0,ncores)]*rep
		d4s=[d4+str(i) for i in range(0,ncores)]*rep
		#print(d1s)
		#d2s=[d2+str(i) for i range(0,ncores)]*rep
		return iter((datal[i],d1s[i],d2s[i],d3s[i],d4s[i]) for i in range(0,len(datal)))

	#
	maxl=len(list(pmid_to_abs.keys()))
	tot=0
	start=time.time()
	#
	# res=[]
	# inps=distro(list(pmid_to_abs.keys()),ncores,'abs_dict_','syn_dict_','abb_dict_')
	# while (inp := next(inps,False)):
	# 	print(inp)
	# 	res.append(list(itertools.starmap(find_in_series,inp)))
	# print(res)
	# res=[i for i in res if i]
	# print(res)
	# res=list(itertools.chain.from_iterable(res))
	# for t in res:
	# 	genes_pub[t[0]].append(t[1])

	# print("loop ends")
	# time.sleep(5)
	#
	with Pool(ncores) as pool:
		#res=[pool.apply(find_in_series,args=(idd,globals()["abs_dict_"+str(ids.index(idd))],globals()["syn_dict_"+str(ids.index(idd))])) for idd in ids]   
		print("starmap...")
		res=pool.starmap(find_in_series,distro(list(pmid_to_abs.keys()),ncores,'abs_dict_','syn_dict_','abb_dict_','ful_dict_'))
		print("store in dictionary")
		res=[i for i in res if i]
		res=list(itertools.chain.from_iterable(res))
		for t in res:
			genes_pub[t[0]].append(t[1])
		#tot+=len(ids)/maxl
	#	
	#print("gene extraction", "%.2f percent done" % (100*tot))       
	#
	print('elapsed time, %d Abstracts : %f' % (maxl,time.time()-start))
	#
	genes=list(genes_pub.keys())
	#
	for key in genes:
		if genes_pub[key]==[]:
			del genes_pub[key]
	# update 
	genes=list(genes_pub.keys())
	#
	compress_pickle(wd+"/"+tag+"_ids_to_genes",genes_pub)
	#
	## also save a list of all genes appearing at least once ## 
	tmp=re.sub(tag+"/$","",wd)
	with open(tmp+"NERed_Genes.txt","a") as nered:
		nered.write('\n'.join(genes))

###
print('TOTAL elapsed time, %d Abstracts : %f seconds' % (len(pmid_to_abs),time.time()-all_time))
###
genedf=pd.DataFrame({'PMID':list(itertools.chain.from_iterable(list(genes_pub.values()))),'GENE':list(itertools.chain.from_iterable([[k]*len(v) for k,v in genes_pub.items()]))})
genedf.to_csv(args.outtag,sep='\t',index=False)